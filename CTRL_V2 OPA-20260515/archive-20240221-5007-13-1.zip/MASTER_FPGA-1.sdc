create_clock -name CLK_50M -period 20 -waveform {0 10} [get_nets {clk_50m}]
create_clock -name CLK_100M -period 10 -waveform {0 5} [get_nets {clk_100m}]
create_clock -name CLK_160M -period 6.25 -waveform {0 3.125} [get_nets {clk_160m}]