create_clock -name CRYSTAL_50M -period 20 -waveform {0 10} [get_ports {clk_in}]
create_generated_clock -name CLK_50M -source [get_ports {clk_in}] -master_clock {CRYSTAL_50M} -phase 0 -multiply_by 1 -duty_cycle 50 [get_ports {clk_50m}]
create_generated_clock -name CLK_100M -source [get_ports {clk_in}] -master_clock {CRYSTAL_50M} -phase 0 -multiply_by 2 -duty_cycle 50 [get_ports {clk_100m}]
create_generated_clock -name CLK_160M -source [get_ports {clk_in}] -master_clock {CRYSTAL_50M} -phase 0 -multiply_by 3.2 -duty_cycle 50 [get_ports {clk_160m}]