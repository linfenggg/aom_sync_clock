module RstUnit(
	output	reg rst
);

wire clkosc; //defualt 4.5MHz
EG_LOGIC_CCLK	U_CCLK(
    			.cclk	(clkosc), 
                .en		(1'b1)
);
	
(*keep*) wire asynrst = 1'b0;
	
reg [15:0]	PowerOnDelayCnt;
always @(posedge clkosc or posedge asynrst) begin
	if(asynrst) 
    	PowerOnDelayCnt <= 0;
	else if(PowerOnDelayCnt != 16'hffff) 
   		PowerOnDelayCnt <= PowerOnDelayCnt + 1;
end
	
always @(posedge clkosc or posedge asynrst) begin
	if(asynrst) 
    	rst <= 1'b1;
	else if(PowerOnDelayCnt != 16'hffff) 
    	rst <= 1'b1;
	else 
    	rst <= 1'b0;
end

endmodule
