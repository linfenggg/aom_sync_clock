module power_lim(
    input				clk_i,
	input				rstn_i,

    input [9:0]         din,
    input [17:0]        POWER_K_SET,

    output [9:0]        dout
);

wire [27:0]			result;
lpm_unsigned_mult10x18 lpm_unsigned_mult8x32(	//10x32
	.a		(din),
	.b		(POWER_K_SET),
	.p      (result)
);

assign dout = result >>15;

endmodule